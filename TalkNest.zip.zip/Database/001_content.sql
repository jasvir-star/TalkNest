INSERT INTO messages (content) VALUES
('Hey everyone, welcome to TalkNest!'),
('Glad to be here. This looks awesome.'),
('Have a great day 👋');
